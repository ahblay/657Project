import argparse
import generator

def parse(l):
    output = set()
    for item in l:
        output.add(tuple(item))
    if not l:
        output.add(tuple())
    return output

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", default="_", help="Starting game pattern: '_' means repeating copies of q")
    parser.add_argument("--q", default="xxo", help="Repeating pattern")
    parser.add_argument("--prefixes", nargs="+", default=[], help="Set of prefixes")
    parser.add_argument("--suffixes", nargs="+", default=[], help="Set of suffixes")
    parser.add_argument("--json", type=str, metavar="FOLDER", help="Produce JSON output in the given folder"
)

    args = parser.parse_args()

    outcome = generator.run(args.state, args.q, parse(args.prefixes), parse(args.suffixes), args.json)
    print(outcome)

if __name__ == "__main__":
    main()